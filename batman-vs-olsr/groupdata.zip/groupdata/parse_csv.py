import plotly
import plotly.plotly as py
import plotly.graph_objs as go

import plotly.offline as pyoff

def parse_csv_olsr(filename):
    dic_transmitor= {}

    with open(filename) as csv:
        for line in csv:
            commas = line.split("\",\"")
            db = commas[2].split(" ")[0]
            try:
                dic_transmitor[commas[3]].append((commas[0],int(db)))
            except KeyError:
                dic_transmitor[commas[3]] = [(commas[0],int(db))]


    return dic_transmitor

def parse_csv_batman(filename):
    dic_transmitor= {}
    dic_ogm = {}
    with open(filename) as csv:
        for line in csv:
            commas = line.split("\",\"")
            db = commas[5]
            db = db.split(" ")[0]
            try:
                dic_transmitor[commas[8]].append((commas[1],int(db)))
            except KeyError:
                dic_transmitor[commas[8]] = [(commas[1],int(db))]
            current_dic_originator = {}
            originators = commas[2].split(",")
            #print(f"originator : {originators}")
            for ori in originators:
                try:
                    current_dic_originator = dic_ogm[ori]
                except KeyError:
                    dic_ogm[ori] = {}
                try:
                    current_dic_originator[commas[8]].append((commas[1], commas[9]))
                except KeyError:
                    current_dic_originator[commas[8]] = [(commas[1], commas[9])]

                dic_ogm.update({ori: current_dic_originator})
    input("")
    return dic_transmitor, dic_ogm

def gen_graph_olsr(filename):
    ret_power = parse_csv_olsr(filename)
    traces = []
    for transmito, info in ret_power.items():
        traces = []

        time = [t[0] for t in info]
        power = [p[1] for p in info]
        traces.append(go.Scatter(
                    x=time,
                    y=power,
                    name=f"rcv power on fit01 for tranmitor{transmito}",

                ))

        data = [* traces]
        layout = go.Layout(
            title="PDR for pings from fit01",

            yaxis=dict(
                title='Count'
            ),
            xaxis=dict(title='PDR (percent)'),
            showlegend=True,


        )

        fig = go.Figure(data=data, layout=layout)
        pyoff.plot(fig, filename='{}/rssi-{}'.format(filename.split("/")[0], transmito))

def gen_graph_batman(filename):
    ret_power, ret_count = parse_csv_batman(filename)
    traces = []
    for transmito, info in ret_power.items():
        traces = []

        time = [t[0] for t in info]
        power = [p[1] for p in info]
        traces.append(go.Scatter(
                    x=time,
                    y=power,
                    name=f"rcv power on fit01 for tranmitor{transmito}",

                ))

        data = [* traces]
        layout = go.Layout(
            title="PDR for pings from fit01",

            yaxis=dict(
                title='Count'
            ),
            xaxis=dict(title='PDR (percent)'),
            showlegend=True,


        )

        fig = go.Figure(data=data, layout=layout)
            #   pyoff.plot(fig, filename='{}/rssi-{}'.format(filename.split("/")[0], transmito))


    for originator, dic_count in ret_count.items():
        traces = []
        traces2 = []
        for transmito, times in dic_count.items():
            step = 1
            now = 0
            time_ranges = []
            counts = []
            sequences = []
            presents = []
            count = 0
            max = float(times[-1][0])
            #seqs = [int(item[1].replace("\"", "").split("=")[-1]) for item in times]
            max_seq = int(times[-1][1].replace("\"", "").split("=")[-1])
            cpt=0
            current_seq = 0
            current_sequence = 0
                #  for s in range(max_seq):
                #sequences.append(s)
                #presents.append(int(s in seqs))
                    #if s in seqs:
                    #presents.append(1)
                    #else:
                    #presents.append(0)
            taken_seq = []
            for ti, seq in times:
            #while now+step <= max:
            #    if len(times) <= cpt:
            #        break
            #    ti, seq = times[cpt]
                seq = int(seq.replace("\"", "").split("=")[-1])
                t = float(ti)
                if seq < 8 :#or t < 58:
                    continue
                if seq not in taken_seq:
                    count +=1
                    counts.append(count)
                    time_ranges.append(t)
                    taken_seq.append(seq)
                #if seq <= current_seq:
                    #cpt +=1
                #    continue
                #count += 1

                #current_seq = seq
            #    if t <= now+step:
            #        count += 1
            #        cpt += 1
            #        current_seq = seq
            #    else:
            #        counts.append(count)
            #        time_ranges.append(now+step)

                    #if t <= now+2*step:
                        #                       count = 1
                    #    cpt += 1
                    #    current_seq = seq
                        #  else:
                        #count = 0
            #        now += step
            #counts.append(count)
            #time_ranges.append(now+step)

            traces.append(go.Scatter(
                        x=time_ranges,
                        y=counts,
                        name=f"Number of ogm rcv from tranmister {transmito}",

                    ))
                #traces2.append(go.Bar(
                #                      x=sequences,
                #                 y=presents,
                #                 name=f"Number of ogm rcv from tranmister {transmito}",

                                  #                 ))

        data = [* traces]
        layout = go.Layout(
        title=f"Rcv OGN msg for {originator}",

        yaxis=dict(
            title='Count'
        ),
        xaxis=dict(title='Time ranges'),
        showlegend=True,


        )

        fig = go.Figure(data=data, layout=layout)
        pyoff.plot(fig, filename='{}/cummucount{}'.format(filename.split("/")[0],originator))
#       data = [* traces2]
#        layout = go.Layout(
                           #title=f"Present seq OGN msg for {originator}",

                           #yaxis=dict(
                                      #title='Count'
                                      #          ),
                           #xaxis=dict(title='seq num'),
                           #showlegend=True,


                           #                          )
#
#fig = go.Figure(data=data, layout=layout)
        #pyoff.plot(fig, filename='{}/present{}'.format(filename.split("/")[0],originator))
#gen_graph_batman("t1-r54-a1-ch10-I-12-batman/fit1_subsec")
#gen_graph_batman("t1-r54-a1-ch10-INone-batman/fit1_subsec")
#gen_graph_batman("t5-r54-a1-ch10-I-12-batman/fit1_subsec")
gen_graph_batman("pdrdata_2/t5-r54-a1-ch10-INone-batman/fit1_subsec")
